let startTime = 0;
let elapsedTime = 0;
let intervalId;
let lapId = 1;

const startButton = document.getElementById('play');
const pauseButton = document.getElementById('pause');
const resetButton = document.getElementById('reset');
const lapButton = document.getElementById('lap');
const clearButton = document.getElementById('clear');
const lapContainer = document.getElementById('lap-container');

const calculateElapsedTime = () => elapsedTime = Date.now() - startTime;


const printElapsedTime = () => {
    
    let hoursDelta = elapsedTime / 3600000;
    let hours = Math.floor(hoursDelta);

    let minutesDelta = (hoursDelta - hours) * 60;
    let minutes = Math.floor(minutesDelta);

    let secondsDelta = (minutesDelta - minutes) * 60;
    let seconds = Math.floor(secondsDelta);

    let centisecondsDelta = (secondsDelta - seconds) * 10;
    let centiseconds = Math.floor(centisecondsDelta);
    
    const formattedHours = hours.toString().padStart(2, "0");
    const formattedMinutes = minutes.toString().padStart(2, "0");
    const formattedSeconds = seconds.toString().padStart(2, "0");
    const formattedCentiseconds = centiseconds.toString().padStart(2, "0");
    
    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}:${formattedCentiseconds}`;
}    

const reset = () => {  
        clearInterval(intervalId);
        elapsedTime = 0;
        document.getElementById("display").innerHTML = "00:00:00:00";
        pauseButton.classList.add("hide");
        startButton.classList.remove("hide");
    }

const start = () => {
   
        startTime = Date.now() - elapsedTime;
        intervalId = setInterval(() => {
            calculateElapsedTime();
            document.getElementById("display").innerHTML = printElapsedTime();
        },100); 
    
    pauseButton.classList.remove("hide");
    startButton.classList.add("hide");
}

const pause = () => {
    clearInterval(intervalId);
    pauseButton.classList.add("hide");
    startButton.classList.remove("hide");
}

const addLap = () => {
    window.localStorage.setItem(`lap-${lapId}`, printElapsedTime());
    renderLaps();
    lapId++;
}

const renderLaps = () => {
    lapContainer.replaceChildren();
    for (let i = 0; i < localStorage.length; i++) {
        var li = document.createElement("li");
        li.appendChild(document.createTextNode(`${localStorage.key(i)} - ${window.localStorage.getItem(localStorage.key(i))}`));
        lapContainer.appendChild(li);
    }
}

const clearLaps = () => {
    window.localStorage.clear();
    lapContainer.replaceChildren();
    lapId = 1;
}

resetButton.addEventListener('click', reset);
startButton.addEventListener('click', start);
pauseButton.addEventListener('click', pause);
lapButton.addEventListener('click', addLap);
clearButton.addEventListener('click', clearLaps);

renderLaps();
